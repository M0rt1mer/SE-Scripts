﻿/*
 *   R e a d m e
 *   -----------
 * 
 *   TargetControl shows list of targets on screen and allows selection
 * 
 */